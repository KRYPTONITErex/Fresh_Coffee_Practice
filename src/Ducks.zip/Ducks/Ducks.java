package Ducks;

public class Ducks {
    public static void main(String[]args){

        Duck mallardDuck = new MallardDuck();
        mallardDuck.setName("Donald Duck"); mallardDuck.setColor("Green");
        mallardDuck.setAge(3); mallardDuck.display();

        System.out.println();

        Duck rubberDuck = new RubberDuck();
        rubberDuck.setName("Dooby Duck"); rubberDuck.setColor("Yellow");
        rubberDuck.setAge(1); rubberDuck.display();

        System.out.println();

        Duck rubberDuck2 = new RubberDuck();
        rubberDuck2.setName("LP's toy duck"); rubberDuck2.setColor("blue");
        rubberDuck2.setAge(2); rubberDuck2.display();

        System.out.println();

        Duck mallardDuck2 = new MallardDuck();
        mallardDuck2.setName("Daisy Duck"); mallardDuck2.setColor("white");
        mallardDuck2.setAge(5); mallardDuck2.display();

    }
}