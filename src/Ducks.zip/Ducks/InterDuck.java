package Ducks;

public interface InterDuck {

    void display();

    void swim();

}
